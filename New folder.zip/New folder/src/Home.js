import React,{Component} from 'react';
import ReactDOM from 'react-dom';

class Home extends Component{
  render(){
    return <div>
                <h1>Hello guys...</h1>
                <p>You are with NIk Coder.!</p>
          </div>
  }
}

export default Home;