import React from 'react';
import ReactDOM from 'react-dom';
import Avatarlist from './Avatarlist';
import './avatar.css';
import 'tachyons';

// class Avatar extends Component {
// 	render(){
// 		return(
// 				const avatarlistcontainer = [
// 					{
// 						id:1,
// 						name:'Nik',
// 						work: 'React Native Developer'
// 					},
// 					{
// 						id:2,
// 						name:'Sooraj',
// 						work: 'Full stack Developer'
// 					},
// 					{
// 						id:3,
// 						name:'Roopesh',
// 						work: 'Frond End Developer'
// 					},
// 					{
// 						id:4,
// 						name:'Rahul',
// 						work: 'React Developer'
// 					}
// ]


// const avtarcard = avatarlistcontainer.map((avatarcard,i) => {

// 	return <Avatarlist id={avatarlistcontainer[i].name} 
// 					   name={avatarlistcontainer[i].name}
// 					   work={avatarlistcontainer[i].work}/>
// })
// const Avatar = (props) => {
// 	return(
// 			<div className="tc">
// 				<h2 className="tc">Welcome My Component</h2>
// 				{avtarcard}			
// 				<button className="db center">Subscribe</button>
// 			</div>
// 		)
// } 		
// 			)
// 	}
// } 
			

			
const avatarlistcontainer = [
					{
						id:1,
						name:'Nik',
						work: 'React Native Developer'
					},
					{
						id:2,
						name:'Sooraj',
						work: 'Full stack Developer'
					},
					{
						id:3,
						name:'Roopesh',
						work: 'Frond End Developer'
					},
					{
						id:4,
						name:'Rahul',
						work: 'React Developer'
					}
]


const avtarcard = avatarlistcontainer.map((avatarcard,i) => {

	return <Avatarlist id={avatarlistcontainer[i].name} 
					   name={avatarlistcontainer[i].name}
					   work={avatarlistcontainer[i].work}/>
})
const Avatar = (props) => {
	return(
			<div className="tc">
				<h2 className="tc">Welcome My Component</h2>
				{avtarcard}			
				<button className="db center">Subscribe</button>
			</div>
		)
} 
	
export default Avatar;