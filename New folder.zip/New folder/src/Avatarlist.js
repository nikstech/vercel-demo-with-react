import React from 'react';

const Avatarlist = (props) => {
	return(
			<div className="avatar ma4 pa2 dib bg-light-purple grow shadow-4">
				<img src={`https://joeschmoe.io/api/v1/${props.name}`} alt="avatar"/>
				<h2 className="tc">{props.name}</h2>
				<p className="tc">{props.work}</p>
			</div>
		)
} 

export default Avatarlist;