import React,{Component} from 'react';
import ReactDOM from 'react-dom';
import './Procss.css';

const Propsdemo = ({name}) => {
		return <div className="container">
                <h1>Hello guys below para is coming from PROPS</h1>
                <p>You are with {name} Coder..!</p>
          </div>
}

export default Propsdemo;

// class Props extends Component{
//   render(){
//     return <div className="container">
//                 <h1>Hello guys below para is coming from PROPSa</h1>
//                 <p>You are with {this.props.name} Coder..!</p>
//           </div>
//   }
// }

// export default Props;  
